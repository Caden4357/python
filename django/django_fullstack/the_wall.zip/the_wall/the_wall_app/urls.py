from django.urls import path, include
from . import views

urlpatterns = [
    path('post/message', views.post_message)
]