from django.shortcuts import render, redirect
from django.contrib.messages.api import error
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *


def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == "GET":
        return redirect('/')
    errors = User.objects.basic_validator(request.POST)
    if errors:
        for key,value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        user = User.objects.register(request.POST)
        request.session['user_id'] = user.id
        return redirect('/blog')

def login(request):
    if request.method == "GET":
        return redirect('/')
    if not User.objects.authenticate(request.POST['email_address'], request.POST['password']):
        messages.error(request, "Invalid Email or Password")
        return redirect('/')
    user = User.objects.get(email_address=request.POST['email_address'])
    request.session['user_id'] = user.id
    return redirect('/blog')

def blog_page(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
        'liked_trips': Trip.objects.filter(going_on_trip=user),
        'trips': Trip.objects.all().exclude(creator_of_trip=user),
        'users_trips': Trip.objects.filter(creator_of_trip=user)
    }
    return render(request, 'travel_home.html', context)

def new_trip(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
    }
    return render(request, 'add_trip.html',context)

def create_trip(request):
    if request.method == "GET":
        return redirect('/blog')
    errors = Trip.objects.trip_validator(request.POST)
    if errors:
        for key,value in errors.items():
            messages.error(request, value)
        return redirect('/new_trip')
    else:
        user = User.objects.get(id=request.session['user_id'])
        trip = Trip.objects.create(
        destination = request.POST['destination'],
        start_date = request.POST['start_date'],
        end_date = request.POST['end_date'],
        plan = request.POST['plan'],
        creator_of_trip = user 
    )
    user = User.objects.get(id = request.session['user_id'])
    trip = trip
    trip.going_on_trip.add(user)
    return redirect('/blog')

def display_trip(request, id):
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'trip': Trip.objects.get(id=id),
    }
    return render(request, 'display.html', context)

def edit(request, id):
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
        'trip': Trip.objects.get(id=id)
    }
    return render(request, 'edit.html', context)

def update(request, id):
    if request.method == "POST":
        errors = Trip.objects.trip_validator(request.POST)
        if errors:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect(f"/edit/{id}")
        trip_to_update = Trip.objects.get(id=id)
        trip_to_update.destination = request.POST['destination']
        trip_to_update.start_date = request.POST['start_date']
        trip_to_update.end_date = request.POST['end_date']
        trip_to_update.plan = request.POST['plan']
        trip_to_update.save()
        return redirect('/blog')

def join_trip(request, id):
    user = User.objects.get(id = request.session['user_id'])
    trip = Trip.objects.get(id=id)
    user.people.add(trip)
    return redirect('/blog')

def cancel(request, id):
    user = User.objects.get(id = request.session['user_id'])
    trip = Trip.objects.get(id=id)
    user.people.remove(trip)
    return redirect('/blog')

def delete(request, id):
    if request.method == "GET":
        return redirect('/')
    to_delete = Trip.objects.get(id=id)
    to_delete.delete()
    return redirect('/blog')

def logout(request):
    request.session.clear()
    return redirect('/')
