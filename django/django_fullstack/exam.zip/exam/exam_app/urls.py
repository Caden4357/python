from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('login', views.login),
    path('blog', views.blog_page),
    path('new_trip', views.new_trip),
    path('create_trip', views.create_trip),
    path('display/<int:id>', views.display_trip),
    path('edit/<int:id>', views.edit),
    path('update/<int:id>', views.update),
    path('join_trip/<int:id>', views.join_trip),
    path('cancel/<int:id>', views.cancel),
    path('destroy/<int:id>', views.delete),
    path('logout', views.logout),
]
