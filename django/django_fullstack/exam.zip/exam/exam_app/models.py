from django.contrib.messages.api import error
from django.db import models
from django.db import models
from django.db.models.base import Model
from django.http import request
import bcrypt 
import re 
from datetime import date, datetime, timedelta



#checking if email is proper email format 
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
date = datetime.strftime(datetime.today(), '%Y-%m-%d')
class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        if len(postData['first_name']) < 2:
            errors["first_name"] = "First Name should be at least 2 characters"

        if len(postData['last_name']) < 2:
            errors["last_name"] = "Last Name should be at least 2 characters"

        #checking for proper email format 
        if not EMAIL_REGEX.match(postData['email_address']):
            errors['email_address'] = "invalid email address"

        #checking for duplicate email address
        email_check = User.objects.filter(email_address = postData['email_address'])
        if email_check:
            errors['duplicate'] = "Email already registered to an account"

        if len(postData['password']) < 8:
            errors["password"] = "Password should be at least 8 characters"

        if postData['pw_confirm'] != postData['pw_confirm']:
            errors['password'] = "Passwords do not match"
        return errors

    def register(self, postData):
        #encrypting password with salt 
        pw = bcrypt.hashpw(postData['password'].encode(), bcrypt.gensalt()).decode()
        return User.objects.create(
            first_name = postData['first_name'],
            last_name = postData['last_name'],
            email_address = postData['email_address'],
            password = pw,
        )
    
    def authenticate(self, email_address, password):
        users = User.objects.filter(email_address=email_address)
        if users:
            user=users[0]
            if bcrypt.checkpw(password.encode(), user.password.encode()):
                return True
            else:
                return False
                

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email_address = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class TravelManager(models.Manager):
    def trip_validator(self, postData):
        errors = {}
        start_date = postData['start_date']
        if len(postData['destination']) < 3:
            errors["destination"] = "Destination must be 3 or more characters"

        if len(postData['start_date']) == 0:
            errors["start_date"] = "Start Date Cannot Be Empty"
        
        if postData['start_date'] < date:
            errors["start_date"] = "Start Date Cannot Be In The Past"


        if postData['end_date'] < start_date:
            errors["end_date"] = "End Date Must Be After Start Date"

            
        if len(postData['end_date']) == 0:
            errors["end_date"] = "End Date Cannot Be Empty"

        if len(postData['plan']) < 3:
            errors["plan"] = "Plan must be 3 or more characters"

        return errors

class Trip(models.Model):
    destination = models.CharField(max_length=255)
    start_date = models.DateField(null=False)
    end_date = models.DateField(null=False)
    plan = models.TextField(max_length=1000)
    creator_of_trip = models.ForeignKey(User, related_name = "creator",on_delete=models.CASCADE)
    going_on_trip = models.ManyToManyField(User, related_name="people")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = TravelManager()
