## Objectives

### Protect POST routes 
- CSRF Token
- create/update/delete should be post request and check if(request.method=="POST"):


### Validation - Custom model manager and  inheriting from models.manager interface
* Many to many realtionship - Actor

### Breakout rooms
1. Ninja Gold	
2. Users (shell)
3. Users with Templates
4. Dojo & Ninjas (Shell)
5. Books/Authors (Shell)
6. Semi-Restful TV Shows
7. Semi-Restful TV Shows Validated
