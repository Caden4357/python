from django.apps import AppConfig


class ClubappConfig(AppConfig):
    name = 'clubapp'
