>> Exam Review(complete as much as we can)
* Define Models and stablish realtionships
* Stablish routes in urls.py
* Register and login (validations & session)
* Create clubs
* Show clubs 
    - user's clubs
    - user is member - clubs
    - Other clubs for user to join
* Join and Drop functionality 
* Show club 
* Edit and Delete club
* Date validation

>> Breakout rooms 

1 Dojo & Ninjas (Shell)
2 Books/Authors (Shell)
3 Semi-Restful TV Shows
4 Semi-Restful TV Shows Validated
5 Courses
6 Amadon
7 Login and Registration
8 Wall
9 Fav Books
