>> Exam expectations
* Exam code- Friday
* 3 attempts - last date to turn in- 5/26
* Orange Belt- 24 hrs/Basic functionality
* Red Belt- 5 hrs/ Basic + red belt features
* Black Belt - 5 hrs/ Basic + Red + Black belt features + 24hrs AWS deployment 

>> Exam preview
### Login and Registration with Club app
* Pattern Validation
* Bcrypt
* Club app

>> Breakout rooms 
1. 	Dojo & Ninjas (Shell)
2. 	Books/Authors (Shell)
3. Semi-Restful TV Shows
4. Semi-Restful TV Shows Validated
5. Courses
6. Amadon
7. Login and Registration





