from django.shortcuts import render, redirect
from .models import *

def index(request):
    context = {
        'all_shows': Show.objects.all()
    }
    return render(request, 'index.html', context)

def show_new(request):
    return render(request, 'add_show.html')

def show_create(request):
    if request.method == 'POST':
        this_show = Show.objects.create(
            title = request.POST['title'],
            description = request.POST['description'],
            release_date = request.POST['release_date'],
            network = request.POST['network']
        )
        return redirect(f"/shows/{this_show.id}")
    else:
        return redirect('/')

def show_show(request, id):
    context = {
        'this_show': Show.objects.get(id=id)
    }
    return render(request, 'show.html', context)

def show_edit(request, id):
    context = {
        'show': Show.objects.get(id=id)
    }
    return render(request, 'edit.html', context)

def show_update(request, id):
    show_to_update = Show.objects.get(id=id)
    show_to_update.title = request.POST['title']
    show_to_update.description = request.POST['description']
    show_to_update.release_date = request.POST['release_date']
    show_to_update.network = request.POST['network']
    show_to_update.save()
    return redirect(f"/shows/{show_to_update.id}")

def show_destroy(request, id):
    to_delete = Show.objects.get(id=id)
    to_delete.delete()
    return redirect('/')

